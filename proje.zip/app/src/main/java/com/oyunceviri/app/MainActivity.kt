package com.oyunceviri.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val BG = 0xFF0E0F13.toInt()
    private val CARD = 0xFF1A1C23.toInt()
    private val ACCENT = 0xFF7C5CFF.toInt()
    private val RED = 0xFFE5484D.toInt()
    private val MUTED = 0xFF9AA0AE.toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val REQ_CAP = 42
    private val REQ_NOTIF = 43

    private lateinit var p: Prefs
    private lateinit var startBtn: Button
    private lateinit var statusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            applyInsets(v, ins)
            ins
        }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(16), dp(18), dp(32))
        scroll.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))
        buildUi(col)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- Arayüz ----------

    private fun buildUi(col: LinearLayout) {
        col.addView(TextView(this).apply {
            text = "Oyun Çeviri"
            setTextColor(Color.WHITE)
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(note("Ekrandaki yabancı altyazıyı okuyup Türkçeye çevirir, orijinalin üstüne kutu olarak koyar."))

        statusTv = note("")
        col.addView(statusTv)

        startBtn = Button(this).apply {
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(56)).apply { topMargin = dp(12) }
            setOnClickListener { onStartClicked() }
        }
        col.addView(startBtn)

        // Dil
        val c1 = card(col, "Oyundaki altyazı dili")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Langs.list.map { it.first })
        spinner.setSelection(Langs.list.indexOfFirst { it.second == p.srcLang }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                p.srcLang = Langs.list[pos].second
            }

            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        c1.addView(spinner)
        c1.addView(note("İlk kullanımda dil paketi (yaklaşık 30 MB) indirilir, internet gerekir. Sonra çevrimdışı çalışır."))

        // Motor
        val c2 = card(col, "Çeviri motoru")
        c2.addView(note("Varsayılan: cihaz içi çeviri (ücretsiz, kotasız). Gemini daha doğal çevirir ama kota harcar; hata verirse otomatik cihaz içine döner."))
        c2.addView(Switch(this).apply {
            text = "Gemini kullan"
            setTextColor(Color.WHITE)
            isChecked = p.useGemini
            setOnCheckedChangeListener { _, v -> p.useGemini = v }
        })
        val keyEt = EditText(this).apply {
            hint = "Gemini API anahtarı (AQ. ya da AIza ile başlar)"
            setText(p.apiKey)
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF6B7280.toInt())
            textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        onText(keyEt) { p.apiKey = it }
        c2.addView(keyEt)
        val modelTv = note("Model: " + p.model.ifEmpty { "otomatik (gemini-2.5-flash)" })
        c2.addView(modelTv)
        c2.addView(smallBtn("Modelleri getir ve seç") { b ->
            val key = p.apiKey
            if (key.isEmpty()) {
                toast("Önce anahtarı gir")
                return@smallBtn
            }
            b.isEnabled = false
            Thread {
                try {
                    val list = listGeminiModels(key)
                    runOnUiThread {
                        b.isEnabled = true
                        if (list.isEmpty()) {
                            toast("Bu anahtarla kullanılabilir model bulunamadı")
                        } else {
                            AlertDialog.Builder(this)
                                .setTitle("Model seç (${list.size})")
                                .setItems(list.toTypedArray()) { _, i ->
                                    p.model = list[i]
                                    modelTv.text = "Model: " + list[i]
                                }
                                .show()
                        }
                    }
                } catch (e: Exception) {
                    val msg = if (e is GeminiError) "HTTP ${e.code}: ${e.body.take(140)}" else (e.message ?: "hata")
                    runOnUiThread {
                        b.isEnabled = true
                        toast("Anahtar/model hatası. $msg")
                    }
                }
            }.start()
        })

        // Tarama
        val c3 = card(col, "Tarama alanı ve hızı")
        c3.addView(note("Altyazının çıktığı bölgeyi daralt: daha az yanlış okuma, daha az pil."))
        seek(c3, "Başlangıç (üstten)", 0, 90, p.scanTop, { "%$it" }) { p.scanTop = it }
        seek(c3, "Bitiş (üstten)", 10, 100, p.scanBottom, { "%$it" }) { p.scanBottom = it }
        seek(c3, "Tarama aralığı", 300, 3000, p.intervalMs, { "$it ms" }) { p.intervalMs = it }

        // Kutu
        val c4 = card(col, "Çeviri kutusu")
        seek(c4, "Yazı boyutu", 12, 30, p.textSp, { "$it sp" }) { p.textSp = it }
        seek(c4, "Arka plan koyuluğu", 50, 100, p.bgAlpha, { "%$it" }) { p.bgAlpha = it }
        c4.addView(Switch(this).apply {
            text = "Taramada kutuyu kısa süre gizle"
            setTextColor(Color.WHITE)
            isChecked = p.hideProbe
            setOnCheckedChangeListener { _, v -> p.hideProbe = v }
        })
        c4.addView(note("Kutu ekran görüntüsüne de girer. Bu açıkken uygulama orijinal altyazıyı görebilmek için kutuyu çok kısa gizler (hafif titreme olabilir). Paylaşımda 'Tek uygulama' seçersen kapatabilirsin."))

        // Kullanım
        val c5 = card(col, "Nasıl kullanılır")
        c5.addView(note("1) Başlat'a bas, 'üstte göster' iznini aç.\n2) Ekran paylaşımı sorulunca izin ver (Tüm ekran önerilir).\n3) Oyunu aç. Altyazı çıkınca Türkçesi üstüne biner.\n4) Durdurmak için bildirimdeki Durdur'a bas.\n\nBazı oyun ve bulut oyun uygulamaları ekran yakalamayı engeller, o zaman ekran siyah görünür ve çalışmaz. Pil optimizasyonunu bu uygulama için kapatman iyi olur."))
    }

    private fun refresh() {
        val ok = Settings.canDrawOverlays(this)
        statusTv.text = if (ok) "Üstte gösterme izni: açık" else "Üstte gösterme izni: kapalı (Başlat'a basınca açılacak)"
        statusTv.setTextColor(if (ok) 0xFF4ADE80.toInt() else 0xFFFBBF24.toInt())
        val running = OverlayService.running
        startBtn.text = if (running) "Durdur" else "Başlat"
        startBtn.background = rounded(if (running) RED else ACCENT, 16)
    }

    // ---------- Başlat / durdur ----------

    private fun onStartClicked() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 500)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("'Diğer uygulamaların üzerinde göster' iznini aç, sonra geri dön")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        launchCapture()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIF) launchCapture() // bildirim izni verilmese de devam
    }

    private fun launchCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAP)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAP) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .setAction(OverlayService.ACTION_START)
                .putExtra(OverlayService.EXTRA_CODE, resultCode)
                .putExtra(OverlayService.EXTRA_DATA, data)
            startForegroundService(i)
            toast("Başladı. Şimdi oyunu aç.")
            Handler(Looper.getMainLooper()).postDelayed({ refresh(); moveTaskToBack(true) }, 700)
        } else {
            toast("Ekran paylaşımı izni verilmedi")
        }
    }

    // ---------- Yardımcılar ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun rounded(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun note(t: String): TextView = TextView(this).apply {
        text = t
        setTextColor(MUTED)
        textSize = 13f
        setPadding(0, dp(6), 0, dp(4))
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = rounded(CARD, 16)
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(14)
        c.layoutParams = lp
        c.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        })
        parent.addView(c)
        return c
    }

    private fun smallBtn(label: String, onClick: (Button) -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = rounded(0xFF2A2D38.toInt(), 12)
        b.setOnClickListener { onClick(b) }
        val lp = LinearLayout.LayoutParams(MATCH, dp(46))
        lp.topMargin = dp(8)
        b.layoutParams = lp
        return b
    }

    private fun seek(
        parent: LinearLayout, name: String, lo: Int, hi: Int, value: Int,
        fmt: (Int) -> String, onSet: (Int) -> Unit
    ) {
        val tv = TextView(this)
        tv.setTextColor(0xFFCBD0DB.toInt())
        tv.textSize = 14f
        tv.setPadding(0, dp(10), 0, 0)
        tv.text = "$name: ${fmt(value)}"
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = value - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                val x = v + lo
                tv.text = "$name: ${fmt(x)}"
                if (fromUser) onSet(x)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun onText(e: EditText, f: (String) -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                f(s?.toString() ?: "")
            }
        })
    }

    // Android 15'te uygulama kenardan kenara çizilir, bu yüzden durum ve gezinme çubuğu kadar boşluk bırak
    @Suppress("DEPRECATION")
    private fun applyInsets(v: View, ins: WindowInsets) {
        val top: Int
        val bottom: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            top = i.top
            bottom = i.bottom
        } else {
            top = ins.systemWindowInsetTop
            bottom = ins.systemWindowInsetBottom
        }
        v.setPadding(0, top, 0, bottom)
    }
}
