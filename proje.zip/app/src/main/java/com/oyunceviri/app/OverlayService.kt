package com.oyunceviri.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/**
 * Akış: ekranı yakala -> altyazı bölgesini kırp -> görüntü değişti mi bak ->
 * değiştiyse OCR -> metin değiştiyse çevir -> kutuyu orijinal altyazının koordinatına koy.
 * Çeviri/OCR sadece görüntü ya da metin değişince çalışır, bu yüzden API kotası boşa gitmez.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_START = "oc.start"
        const val ACTION_STOP = "oc.stop"
        const val ACTION_TOGGLE = "oc.toggle"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile var running = false
        private const val TAG = "OyunCeviri"
    }

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var hub: TranslatorHub
    private val ocr = Ocr()
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var worker: Handler? = null

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var capW = 0
    private var capH = 0

    private var box: TextView? = null
    @Volatile private var boxShown = false
    @Volatile private var paused = false
    private var note = "Çalışıyor"

    private var lastRegion: Bitmap? = null
    private var regionTop = 0
    private var prevSig: IntArray? = null
    private var doneSig: IntArray? = null
    private var shownNorm = ""
    private var shownTextNorm = ""
    private var shownText = ""
    private var lastRect = Rect()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        hub = TranslatorHub(prefs)
        hub.onNote = { n ->
            note = n
            main.post { notifyNow() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_TOGGLE -> {
                paused = !paused
                if (paused) clearBox()
                notifyNow()
            }
            ACTION_START -> begin(intent)
        }
        return START_NOT_STICKY
    }

    // ---------- Başlatma ----------

    private fun begin(intent: Intent) {
        if (running) return
        createChannel()
        val n = buildNotif()
        // Android 14+: önce foreground servis (mediaProjection tipinde), sonra getMediaProjection
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            legacyData(intent)
        }
        if (data == null) {
            stopSelf()
            return
        }

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data)
            projection = mp
            // Android 14+: createVirtualDisplay'den ÖNCE callback kaydı zorunlu
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }, main)
            setupCapture()
        } catch (e: Exception) {
            Log.e(TAG, "capture", e)
            Toast.makeText(this, "Ekran yakalama başlatılamadı: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        running = true
        val t = HandlerThread("oc-worker")
        t.start()
        thread = t
        worker = Handler(t.looper).also { it.post(tick) }
    }

    @Suppress("DEPRECATION")
    private fun legacyData(i: Intent): Intent? = i.getParcelableExtra<Intent>(EXTRA_DATA)

    @Suppress("DEPRECATION")
    private fun realSize(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun setupCapture() {
        val (w, h, d) = realSize()
        capW = w
        capH = h
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        vd = projection!!.createVirtualDisplay(
            "oyunceviri", w, h, d,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    /** Ekran döndürülünce aynı VirtualDisplay'i yeniden boyutlandırır (Android 14+ yeni VirtualDisplay'e izin vermez). */
    private fun checkSize() {
        val (w, h, d) = realSize()
        if (w == capW && h == capH) return
        val old = reader
        val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.resize(w, h, d)
        vd?.surface = nr.surface
        reader = nr
        old?.close()
        capW = w
        capH = h
        lastRegion?.recycle()
        lastRegion = null
        prevSig = null
        doneSig = null
        clearBox()
    }

    // ---------- Ana döngü ----------

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Throwable) {
                Log.e(TAG, "step", e)
            }
            // Kutu görünürken her taramada gizlemek göz yorar, o yüzden daha seyrek tara
            val gap = if (boxShown && prefs.hideProbe) max(prefs.intervalMs, 1200) else prefs.intervalMs
            worker?.postDelayed(this, gap.toLong())
        }
    }

    private fun step() {
        if (paused) return
        checkSize()
        val rd = reader ?: return

        // Overlay de ekran görüntüsüne girer. Orijinal altyazıyı okumak için kutuyu çok kısa süre gizle.
        val probe = boxShown && prefs.hideProbe
        if (probe) {
            main.post { box?.visibility = View.INVISIBLE }
            Thread.sleep(150)
        }
        val img: Image? = try {
            rd.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (probe) main.post { if (boxShown) box?.visibility = View.VISIBLE }

        val newRegion: Bitmap? = if (img != null) {
            try {
                crop(img)
            } finally {
                img.close()
            }
        } else null
        if (newRegion != null) {
            lastRegion?.recycle()
            lastRegion = newRegion
        }
        val region = lastRegion ?: return
        // Ekran sabitse yeni kare gelmez; o durumda önceki kareyi ve imzayı kullan
        val sig = if (newRegion != null) signature(region) else (prevSig ?: return)

        val last = doneSig
        val changed = last == null || diffCount(sig, last) >= 3
        val prev = prevSig
        val stable = newRegion == null || boxShown || (prev != null && diffCount(sig, prev) < 3)
        prevSig = sig
        if (!changed || !stable) return
        doneSig = sig

        val res = try {
            ocr.recognize(region, prefs.srcLang)
        } catch (e: Exception) {
            Log.w(TAG, "ocr", e)
            doneSig = null
            return
        }
        val lines = res.textBlocks.flatMap { it.lines }
            .filter { l -> l.boundingBox != null && l.text.any { c -> c.isLetter() } }
        if (lines.isEmpty()) {
            clearBox()
            return
        }
        val sorted = lines.sortedBy { it.boundingBox!!.top }
        val text = sorted.joinToString(" ") { it.text.replace('\n', ' ') }.trim()
        val norm = normalize(text)
        if (norm.length < 2) {
            clearBox()
            return
        }
        // Satırların hepsini tek dikdörtgende birleştir, böylece kutu satırlar arasında zıplamaz
        val rect = Rect(sorted[0].boundingBox!!)
        sorted.forEach { rect.union(it.boundingBox!!) }
        rect.offset(0, regionTop)

        // Aynı altyazı (ya da kendi Türkçe kutumuz okunduysa) tekrar çevrilmez
        if (norm == shownNorm || norm == shownTextNorm) {
            if (boxShown && moved(rect)) showBox(shownText, rect)
            return
        }

        val tr = try {
            hub.translate(text, prefs.srcLang)
        } catch (e: Exception) {
            Log.w(TAG, "translate", e)
            note = "Çeviri hatası: ${e.message ?: "bilinmiyor"}"
            main.post { notifyNow() }
            doneSig = null
            return
        }
        shownNorm = norm
        shownText = tr
        shownTextNorm = normalize(tr)
        showBox(tr, rect)
    }

    private fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun moved(r: Rect): Boolean =
        abs(r.centerX() - lastRect.centerX()) > 20 ||
            abs(r.bottom - lastRect.bottom) > 20 ||
            abs(r.width() - lastRect.width()) > 40

    /** Yakalanan kareden sadece altyazı bölgesini keser. */
    private fun crop(img: Image): Bitmap {
        val plane = img.planes[0]
        val rowPixels = plane.rowStride / plane.pixelStride
        val wide = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(plane.buffer)

        val minH = 40
        var t = img.height * prefs.scanTop / 100
        var b = img.height * prefs.scanBottom / 100
        t = t.coerceIn(0, img.height - minH)
        b = b.coerceIn(t + minH, img.height)
        regionTop = t
        val out = Bitmap.createBitmap(wide, 0, t, img.width, b - t)
        if (out !== wide) wide.recycle()
        return out
    }

    /** 64x16 ızgarada ortalama parlaklık. Küçük harf değişikliklerini yakalar, her pikseli karşılaştırmaz. */
    private fun signature(b: Bitmap): IntArray {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val cols = 64
        val rows = 16
        val sum = LongArray(cols * rows)
        val cnt = IntArray(cols * rows)
        var y = 0
        while (y < h) {
            val r = y * rows / h
            var x = 0
            while (x < w) {
                val c = x * cols / w
                val p = px[y * w + x]
                val lum = ((p shr 16) and 255) * 3 + ((p shr 8) and 255) * 6 + (p and 255)
                sum[r * cols + c] += lum.toLong()
                cnt[r * cols + c]++
                x += 2
            }
            y += 2
        }
        return IntArray(cols * rows) { (sum[it] / (10L * max(1, cnt[it]))).toInt() }
    }

    private fun diffCount(a: IntArray, b: IntArray): Int {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 14) n++
        return n
    }

    // ---------- Çeviri kutusu ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun createBox(): TextView {
        val tv = TextView(this)
        tv.setTextColor(Color.WHITE)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(10), dp(6), dp(10), dp(6))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        tv.layoutParams = lp
        return tv
    }

    private fun showBox(text: String, r: Rect) {
        val rect = Rect(r)
        main.post {
            try {
                val tv = box ?: createBox().also { box = it }
                val bg = GradientDrawable()
                bg.cornerRadius = dp(12).toFloat()
                bg.setColor(Color.argb(prefs.bgAlpha * 255 / 100, 12, 12, 16))
                bg.setStroke(dp(1), Color.argb(70, 255, 255, 255))
                tv.background = bg
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.textSp.toFloat())
                tv.text = text

                // Kutu orijinal altyazıyı tamamen örtecek kadar geniş ve yüksek olsun
                val pad = dp(10)
                val minW = (capW * 0.45f).toInt()
                val w = max(rect.width() + 2 * pad, minW).coerceAtMost(capW - dp(8))
                tv.minHeight = rect.height() + dp(12)
                val lp = tv.layoutParams as WindowManager.LayoutParams
                lp.width = w
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT
                tv.measure(
                    View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
                )
                val h = tv.measuredHeight
                // Altı orijinal altyazının altıyla hizalı; Türkçe uzunsa yukarı doğru büyür
                lp.x = (rect.centerX() - w / 2).coerceIn(0, max(0, capW - w))
                lp.y = (rect.bottom + dp(6) - h).coerceIn(0, max(0, capH - h))

                if (tv.parent == null) wm.addView(tv, lp) else wm.updateViewLayout(tv, lp)
                tv.visibility = View.VISIBLE
                lastRect = rect
                boxShown = true
            } catch (e: Exception) {
                Log.e(TAG, "showBox", e)
                note = "Kutu gösterilemedi: 'Diğer uygulamaların üzerinde göster' izni açık mı?"
                notifyNow()
            }
        }
    }

    private fun clearBox() {
        shownNorm = ""
        shownTextNorm = ""
        shownText = ""
        main.post {
            box?.let {
                if (it.parent != null) {
                    try {
                        wm.removeView(it)
                    } catch (e: Exception) {
                        Log.w(TAG, "removeView", e)
                    }
                }
            }
            boxShown = false
        }
    }

    // ---------- Bildirim ----------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("ceviri", "Oyun Çeviri", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotif(): Notification {
        fun pi(action: String, code: Int): PendingIntent = PendingIntent.getService(
            this, code,
            Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, "ceviri")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Oyun Çeviri")
            .setContentText(if (paused) "Duraklatıldı" else note)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, if (paused) "Devam" else "Duraklat", pi(ACTION_TOGGLE, 1)).build())
            .addAction(Notification.Action.Builder(null, "Durdur", pi(ACTION_STOP, 2)).build())
            .build()
    }

    private fun notifyNow() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotif())
    }

    // ---------- Kapanış ----------

    override fun onDestroy() {
        running = false
        worker?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        try { vd?.release() } catch (e: Exception) { Log.w(TAG, "vd", e) }
        reader?.close()
        try { projection?.stop() } catch (e: Exception) { Log.w(TAG, "mp", e) }
        box?.let {
            if (it.parent != null) {
                try { wm.removeView(it) } catch (e: Exception) { Log.w(TAG, "rm", e) }
            }
        }
        boxShown = false
        lastRegion?.recycle()
        ocr.close()
        hub.close()
        super.onDestroy()
    }
}
